package com.allianz.healthCheck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.Portfolio;
import com.allianz.healthCheck.domain.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {

	List<Project> findByPortfolio(Portfolio portfolio);
	
	Project findByProjectName(String projectName);

}
