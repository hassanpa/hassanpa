package com.allianz.healthCheck.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.OperatingEntity;
import com.allianz.healthCheck.domain.ServiceOffering;

@Repository
public interface ServiceOfferingRepository extends JpaRepository<ServiceOffering, Integer> {

	List<ServiceOffering> findByOperatingEntity(Optional<OperatingEntity> operatingEntity);

	


	
}
