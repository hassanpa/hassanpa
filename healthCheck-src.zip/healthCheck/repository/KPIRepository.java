package com.allianz.healthCheck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.KPI;
import com.allianz.healthCheck.domain.Project;

@Repository
public interface KPIRepository extends JpaRepository<KPI, Integer> {

	List<KPI> findByProject(Project project);

}
