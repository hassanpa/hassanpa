package com.allianz.healthCheck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.OperatingEntity;

@Repository
public interface OperatingEntityRepository extends JpaRepository<OperatingEntity, Integer> {

}
