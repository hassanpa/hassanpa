package com.allianz.healthCheck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.KPIMaster;

@Repository
public interface KPIMasterRepository extends JpaRepository<KPIMaster, Integer> {


}
