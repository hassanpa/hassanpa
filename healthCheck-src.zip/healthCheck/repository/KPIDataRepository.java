package com.allianz.healthCheck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.allianz.healthCheck.domain.KPI;
import com.allianz.healthCheck.domain.KPIData;

@Repository
public interface KPIDataRepository extends JpaRepository<KPIData, Integer> {
	
	KPIData findBykpi(KPI kpi);

	@Query("SELECT D FROM KPIData D WHERE KPI_ID=:kpiId AND MONTH(reporting_period)=:period")
	List<KPIData> find(int kpiId, int period);
	
	
	

}
