package com.allianz.healthCheck.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.service.OrganizationService;

@RestController
public class OrganizationController {

	@Autowired
	OrganizationService organizationService;

	@RequestMapping(value = "/index")
	public ModelAndView showHomePage() {
		return new ModelAndView("index", "", null);
	}

	@RequestMapping(value = "/organization")
	public ResponseEntity<List<Organization>> getOrganizations() {
		List<Organization> allrecords = organizationService.findAll();
		return ResponseEntity.ok().body(allrecords);

	}
	
	@RequestMapping(value = "/organization/{organizationName}")
	public ResponseEntity<Organization> getOrganization(@PathVariable String organizationName) {
		Organization organization=  organizationService.findOrganization(organizationName);
		return ResponseEntity.ok().body(organization);

	}

	@RequestMapping(value = "/saveOrganization")
	public ResponseEntity<Organization> create(@RequestBody Organization organization) {
		Organization savedEntity = organizationService.save(organization);
		return ResponseEntity.ok().body(savedEntity);
	}

	@RequestMapping(value = "/createOrganization", method = RequestMethod.GET)
	public ModelAndView createOrganization() {
		return new ModelAndView("createOrganization", "org", new Organization());
	}

//	 @RequestMapping("/saveOrganization")
//		public ModelAndView create(@Valid @ModelAttribute("org")Organization organization,final BindingResult result) {
//			if(result.hasErrors()) {
//				 ModelAndView modelAndView = new ModelAndView();
//				 modelAndView.setViewName("createOrganization");
//				 return modelAndView;
//			}
//			Organization savedEntity = portfolioService.save(organization);
//			List<Organization> allrecords=new ArrayList<Organization>();
//			allrecords.add(savedEntity);
//			return new ModelAndView("organization", "organizations", allrecords);
//		}

//	 @RequestMapping(value="/organization")
//		public ModelAndView showAllRecords() {
//			List<Organization> allrecords = portfolioService.findAll();
//			return new ModelAndView("organization", "organizations", allrecords);
//		}
}
