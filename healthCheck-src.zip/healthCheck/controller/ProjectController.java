package com.allianz.healthCheck.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.healthCheck.domain.KPI;
import com.allianz.healthCheck.domain.KPIData;
import com.allianz.healthCheck.domain.OperatingEntity;
import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.domain.Portfolio;
import com.allianz.healthCheck.domain.Project;
import com.allianz.healthCheck.domain.ServiceOffering;
import com.allianz.healthCheck.dto.ProjectDTO;
import com.allianz.healthCheck.service.KPIDataService;
import com.allianz.healthCheck.service.KPIService;
import com.allianz.healthCheck.service.PortfolioService;
import com.allianz.healthCheck.service.ProjectService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	PortfolioService portfolioService;
	@Autowired
	KPIDataService kpiDataService;
	@Autowired
	KPIService kpiService;

	@GetMapping("")
	public List<ProjectDTO> getProjectsByPortfolio(@RequestParam(required = true) Integer portfolioId) {
		List<KPI> kpiList;
		List<KPIData> kpiDatasList;
		int activeSLA=0;
		int atRiskSLA=0;
		int breachedSLA=0;
		Optional<Portfolio> portfolio = portfolioService.findById(portfolioId);

		ServiceOffering serviceOffering = loadServiceOfferings(portfolio);

		OperatingEntity operatingEntity = loadOperatingEntity(portfolio);

		Organization organization = loadOrganization(portfolio);

		operatingEntity.setOrganization(organization);
		serviceOffering.setOperatingEntity(operatingEntity);
		portfolio.get().setServiceOffering(serviceOffering);

		ProjectDTO projectDTO;
		List<ProjectDTO> projectDTOList = new ArrayList<>();
		List<Project> projects = projectService.getProjectsByPortfolio(portfolio.get());
		for (Project project : projects) {
			projectDTO = new ProjectDTO();
			ModelMapper modelMapper = new ModelMapper();
			modelMapper.map(project, projectDTO);
			
			 kpiList= kpiService.getProjectKPIs(project);
			 
			 kpiDatasList= kpiDataService.getKPIDatas(kpiList);
			 for (KPIData kpiData : kpiDatasList) {
				 int thresholdMax=kpiData.getKpi().getThresholdMax();
				 int thresholdMin=kpiData.getKpi().getThresholdMin();
				 int thresholdValue= kpiData.getValue();
				if(thresholdValue!=0) {
					if(thresholdValue >= thresholdMin && thresholdValue <= thresholdMax) {
						activeSLA++;
					}else if(thresholdValue < thresholdMin) {
						atRiskSLA++;
					}else {
						breachedSLA++;
					}
				}
			}
			 projectDTO.setActiveSLA(activeSLA);
			 projectDTO.setAtRiskSLA(atRiskSLA);
			 projectDTO.setBreachedSLA(breachedSLA);
			projectDTOList.add(projectDTO);
		}

		return projectDTOList;
	}

	private ServiceOffering loadServiceOfferings(Optional<Portfolio> portfolio) {
		ServiceOffering serviceOffering = new ServiceOffering();
		serviceOffering.setId(portfolio.get().getServiceOffering().getId());
		serviceOffering.setServiceName(portfolio.get().getServiceOffering().getServiceName());
		serviceOffering.setServiceDecription(portfolio.get().getServiceOffering().getServiceDecription());
		serviceOffering.setBusinessWeightage(portfolio.get().getServiceOffering().getBusinessWeightage());
		return serviceOffering;
	}

	private Organization loadOrganization(Optional<Portfolio> portfolio) {
		Organization organization = new Organization();
		organization.setId(portfolio.get().getServiceOffering().getOperatingEntity().getOrganization().getId());
		organization
				.setCountry(portfolio.get().getServiceOffering().getOperatingEntity().getOrganization().getCountry());
		organization.setOrganization(
				portfolio.get().getServiceOffering().getOperatingEntity().getOrganization().getOrganization());
		organization.setOrganizationDescription(portfolio.get().getServiceOffering().getOperatingEntity()
				.getOrganization().getOrganizationDescription());
		return organization;
	}

	private OperatingEntity loadOperatingEntity(Optional<Portfolio> portfolio) {
		OperatingEntity operatingEntity = new OperatingEntity();
		operatingEntity.setId(portfolio.get().getServiceOffering().getOperatingEntity().getId());
		operatingEntity.setOperatingEntityName(
				portfolio.get().getServiceOffering().getOperatingEntity().getOperatingEntityName());
		operatingEntity.setCountry(portfolio.get().getServiceOffering().getOperatingEntity().getCountry());
		return operatingEntity;
	}

	
}
