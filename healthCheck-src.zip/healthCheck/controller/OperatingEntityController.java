package com.allianz.healthCheck.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.allianz.healthCheck.domain.OperatingEntity;
import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.service.OperatingEntityService;
import com.allianz.healthCheck.service.OrganizationService;

@RestController
public class OperatingEntityController {

	@Autowired
	OperatingEntityService operatingEntityService;

	@Autowired
	OrganizationService organizationService;

	@RequestMapping(value = "/createOperatingEntity", method = RequestMethod.GET)
	public ModelAndView createOrganization() {
		List<Organization> organizations = organizationService.findAll();

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("createOperatingEntity");
		OperatingEntity operatingEntity = new OperatingEntity();
		modelAndView.addObject("oe", operatingEntity);
		modelAndView.addObject("organizations", organizations);

		return modelAndView;
	}

	@RequestMapping("/saveOperatingEntity")
	public ModelAndView create(@Valid @ModelAttribute("oe") OperatingEntity operatingEntity,
			final BindingResult result) {
		ModelAndView modelAndView = new ModelAndView();
		if (result.hasErrors()) {
			List<Organization> organizations = organizationService.findAll();

			modelAndView.setViewName("createOperatingEntity");
			modelAndView.addObject("oe", operatingEntity);
			modelAndView.addObject("organizations", organizations);

		} else {
			OperatingEntity savedEntity = operatingEntityService.save(operatingEntity);
			Organization organization = savedEntity.getOrganization();
			Integer orgId = organization.getId();
			List<OperatingEntity> oes = operatingEntityService.findByOrganization(orgId);
			System.out.println("" + savedEntity.getId());
			modelAndView.addObject("oes", oes);
			modelAndView.setViewName("operatingEntities");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/searchOE", method = RequestMethod.GET)
	public ModelAndView searchOE() {
		List<Organization> organizations = organizationService.findAll();

		ModelAndView modelAndView = new ModelAndView();

		OperatingEntity operatingEntity = new OperatingEntity();
		modelAndView.addObject("oe", operatingEntity);
		modelAndView.addObject("organizations", organizations);

		modelAndView.setViewName("searchOE");

		return modelAndView;
	}

	@RequestMapping("/filterOE")
	public ModelAndView filterOE(@Valid @ModelAttribute("oe") OperatingEntity operatingEntity,
			final BindingResult result) {
		ModelAndView modelAndView = new ModelAndView();
		Organization organization = operatingEntity.getOrganization();
		Integer orgId = organization.getId();
		List<OperatingEntity> oes = operatingEntityService.findByOrganization(orgId);
		modelAndView.addObject("oes", oes);
		modelAndView.setViewName("operatingEntities");
		return modelAndView;
	}

}
