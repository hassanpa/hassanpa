package com.allianz.healthCheck.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.KPI;
import com.allianz.healthCheck.domain.KPIData;
import com.allianz.healthCheck.domain.Portfolio;
import com.allianz.healthCheck.domain.HealthSummary;
import com.allianz.healthCheck.domain.Project;
import com.allianz.healthCheck.domain.ProjectHealthSummary;
import com.allianz.healthCheck.domain.RAGStatus;

@Service
public class HealthAnalyserService {

	@Autowired
	private Environment env;

	@Autowired
	private KPIDataService kpiDataService;

	@Autowired
	private KPIService kpiService;

	@Autowired
	private ProjectService projectService;

	public RAGStatus getRAGStatus(int actualValue, int maximumThreshold, int minimumThreshhold) {
		if (actualValue >= maximumThreshold) {
			return RAGStatus.GREEN;
		} else if (actualValue < minimumThreshhold) {
			return RAGStatus.RED;
		} else {
			return RAGStatus.AMBER;
		}
	}

	public HealthSummary analyseKPIHealth(KPIData kpiData) {
		int businessWeightage = kpiData.getKpi().getBusinessWeightage();
		int kpiMax = kpiData.getKpi().getThresholdMax();
		int kpiMin = kpiData.getKpi().getThresholdMin();

		int value = kpiData.getValue();
		RAGStatus riskLevel = getRAGStatus(value, kpiMax, kpiMin);

		BigDecimal score = calculateHealthScore(businessWeightage, kpiMax, value, riskLevel);
		HealthSummary kpiSummary = new HealthSummary(kpiData.getKpi().getKpiMaster().getKpiName(), score, riskLevel, value,
				businessWeightage, kpiMax, kpiMin, kpiData.getKpi(), kpiData);
		return kpiSummary;
	}

	private BigDecimal calculateHealthScore(int businessWeightage, int kpiMax, int value, RAGStatus riskLevel) {
		BigDecimal score, weightage = null;
		if (RAGStatus.GREEN == riskLevel) {
			score = BigDecimal.valueOf(businessWeightage);
		} else {
			weightage = BigDecimal.valueOf(businessWeightage).divide(BigDecimal.valueOf(100));
			double temp = (double) value / kpiMax;
			score = BigDecimal.valueOf(temp).multiply(BigDecimal.valueOf(100)).multiply(weightage).setScale(2,
					RoundingMode.HALF_EVEN);
		}
		return score;
	}
	

	public ProjectHealthSummary getHealthSummary(Project project, String remarks) {
		HealthSummary kpiSummary = null;
		List<HealthSummary> projectKpiSummary = new ArrayList<HealthSummary>();
		Integer portofolioMaxThreshold = Integer.valueOf(env.getProperty("portfolioThresholdMax"));
		Integer portofolioMinThreshold = Integer.valueOf(env.getProperty("portfolioThresholdMin"));

		List<KPI> kpis = kpiService.getProjectKPIs(project);
		ProjectHealthSummary portfolioKPISummary = null;
		if (kpis.isEmpty()) {
			portfolioKPISummary = ProjectHealthSummary.create(project.getProjectName(), "No KPI's Defined",
					HealthSummary.create("", BigDecimal.valueOf(100), RAGStatus.GREEN, 10, 100, 0, 0));
		} else {
			List<KPIData> kpiDatas = kpiDataService.getKPIDatas(kpis);

			for (KPIData kpiData : kpiDatas) {
				kpiSummary = analyseKPIHealth(kpiData);
				projectKpiSummary.add(kpiSummary);
			}

			BigDecimal totalScore = HealthSummary.sumOfHealthScore(projectKpiSummary);

			portfolioKPISummary = analyseHealth(project.getProjectName(), remarks, project.getBusinessWeightage(),
					totalScore.intValue(), portofolioMaxThreshold, portofolioMinThreshold, projectKpiSummary);

		}

		return portfolioKPISummary;
	}

	public ProjectHealthSummary analyseHealth(String name, String remarks, int businessWeightage, int score,
			int maxThreshold, int minThreshold, List<HealthSummary> healthSummaries) {

		HealthSummary healthSummary = new HealthSummary();
		healthSummary.setBusinessWeightage(businessWeightage);
		healthSummary.setMaxThreshold(maxThreshold);
		healthSummary.setMinThreshold(minThreshold);
		healthSummary.setKpiName(name);

		RAGStatus ragStatus = getRAGStatus(score, maxThreshold, minThreshold);
		healthSummary.setRAGStatus(ragStatus);

		BigDecimal calculatedScore = calculateHealthScore(businessWeightage, maxThreshold, score, ragStatus);
		healthSummary.setScore(calculatedScore);

		ProjectHealthSummary projectHealthSummary = new ProjectHealthSummary(name, remarks, healthSummary,
				healthSummaries);
		return projectHealthSummary;
	}

	public ProjectHealthSummary getHealthSummary(Portfolio portfolio1_ABBS,String remarks) {
		List<ProjectHealthSummary> healthSummaries = new ArrayList<ProjectHealthSummary>();

		List<Project> projects = projectService.getProjectsByPortfolio(portfolio1_ABBS);
		ProjectHealthSummary summary = null;
		for (Project project : projects) {
			summary = getHealthSummary(project, "Nil");
			System.out.println(summary);
			healthSummaries.add(summary);
		}

		BigDecimal sumOfHealthScore = ProjectHealthSummary.sumOfHealthScore(healthSummaries);

		Integer maxThreshold = Integer.valueOf(env.getProperty("portfolioThresholdMax"));
		Integer minThreshold = Integer.valueOf(env.getProperty("portfolioThresholdMin"));

		ProjectHealthSummary overallHealth = analyseHealth(portfolio1_ABBS.getPortfolioName(), remarks,
				portfolio1_ABBS.getBusinessWeightage(), sumOfHealthScore.intValue(), maxThreshold, minThreshold,
				new ArrayList<HealthSummary>());
		return overallHealth;
	}


}
