package com.allianz.healthCheck.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.OperatingEntity;
import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.repository.OperatingEntityRepository;

@Service
public class OperatingEntityService {

	@Autowired
	private OperatingEntityRepository operatingEntityRepository;

	public List<OperatingEntity> findAll() {
		return operatingEntityRepository.findAll();
	}

	public OperatingEntity save(@Valid OperatingEntity OperatingEntity) {
		@Valid
		OperatingEntity savedEntity = operatingEntityRepository.save(OperatingEntity);
		return savedEntity;
	}

	public List<OperatingEntity> findByOrganization(Integer orgId) {
		OperatingEntity operatingEntity=new OperatingEntity();
		Organization organization=new Organization();
		organization.setId(orgId);
		operatingEntity.setOrganization(organization);
		Example<OperatingEntity> example = Example.of(operatingEntity);
		List<OperatingEntity> records = operatingEntityRepository.findAll(example);
		return records;
		
	}
	
    public Optional<OperatingEntity> findById(Integer oeId) {
    	Optional<OperatingEntity> operatingEntity = operatingEntityRepository.findById(oeId);
    	return operatingEntity;
    }
}
