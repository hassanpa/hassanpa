package com.allianz.healthCheck.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.KPI;
import com.allianz.healthCheck.domain.KPIData;
import com.allianz.healthCheck.repository.KPIDataRepository;

@Service
public class KPIDataService {

	@Autowired
	private KPIDataRepository kpiDataRepository;


	public List<KPIData> findAll() {
		return kpiDataRepository.findAll();
	}

	public KPIData save(@Valid KPIData kpiData) {
		@Valid
		KPIData savedEntity = kpiDataRepository.save(kpiData);
		return savedEntity;
	}

	public List<KPIData> getKPIDatas(List<KPI> kpis) {
		List<KPIData> kpiDatas = new ArrayList<KPIData>();
		for (KPI kpi : kpis) {
			System.out.println(kpi);
			KPIData kpiData = kpiDataRepository.findBykpi(kpi);
			if(kpiData!= null) {
				kpiDatas.add(kpiData);
			}
			

		}
		return kpiDatas;
	}

	
	public List<KPIData> getKPIDatas(List<KPI> kpis, int period) {
		List<KPIData> kpiDatas = new ArrayList<KPIData>();
		for (KPI kpi : kpis) {
			System.out.println(kpi);
			List<KPIData> kpiData = kpiDataRepository.find(kpi.getId(),period);
			kpiDatas.addAll(kpiData);

		}
		return kpiDatas;
	}
	
}
