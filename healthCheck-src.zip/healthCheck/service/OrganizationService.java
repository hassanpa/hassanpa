package com.allianz.healthCheck.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.repository.OrganizationRepository;

@Service
public class OrganizationService {

	@Autowired
	private OrganizationRepository organizationRepository;

	public List<Organization> findAll() {
		return organizationRepository.findAll();
	}

	public Organization save(@Valid Organization organization) {
		@Valid
		Organization savedEntity = organizationRepository.save(organization);
		return savedEntity;
	}

	
	public Organization findOrganization(String organization) {
		return organizationRepository.findByOrganization(organization);
	}

	}
