package com.allianz.healthCheck.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.OperatingEntity;
import com.allianz.healthCheck.domain.Organization;
import com.allianz.healthCheck.domain.ServiceOffering;
import com.allianz.healthCheck.repository.ServiceOfferingRepository;

@Service
public class ServiceOfferingService {

	@Autowired
	private ServiceOfferingRepository serviceOfferingRepository;
	
	@Autowired
	OperatingEntityService operatingEntityService;

	@Autowired
	OrganizationService organizationService;

	public List<ServiceOffering> findAll() {
		return serviceOfferingRepository.findAll();
	}

	public ServiceOffering save(@Valid ServiceOffering serviceOffering) {
		@Valid
		ServiceOffering savedEntity = serviceOfferingRepository.save(serviceOffering);
		return savedEntity;
	}
	
	
	public List<ServiceOffering> findByOperatingEntity(Integer operatingEntityId) {
		
		Optional<OperatingEntity> operatingEntity = operatingEntityService.findById(operatingEntityId);
		
		Organization organization=new Organization();
		organization.setId(operatingEntity.get().getOrganization().getId());
		organization.setOrganization(operatingEntity.get().getOrganization().getOrganization());
		organization.setOrganizationDescription(operatingEntity.get().getOrganization().getOrganizationDescription());
		organization.setCountry(operatingEntity.get().getOrganization().getCountry());
		operatingEntity.get().setOrganization(organization);
		List<ServiceOffering> serviceOfferings= serviceOfferingRepository.findByOperatingEntity(operatingEntity);
		return serviceOfferings;
	}


	
	
}
