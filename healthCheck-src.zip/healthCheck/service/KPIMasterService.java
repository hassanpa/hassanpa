package com.allianz.healthCheck.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.allianz.healthCheck.domain.KPIMaster;
import com.allianz.healthCheck.repository.KPIMasterRepository;

@Service
public class KPIMasterService {

	@Autowired
	private KPIMasterRepository kpiMasterRepository;

	public List<KPIMaster> findAll() {
		return kpiMasterRepository.findAll();
	}

	public KPIMaster save(@Valid KPIMaster project) {
		@Valid
		KPIMaster savedEntity = kpiMasterRepository.save(project);
		return savedEntity;
	}

}
