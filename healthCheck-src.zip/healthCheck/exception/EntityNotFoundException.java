package com.allianz.healthCheck.exception;

public class EntityNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 5391250576616157408L;

	public EntityNotFoundException() {
		
	}
	
	public EntityNotFoundException(String message,Throwable cause) {
		super(message,cause);
	}
}
