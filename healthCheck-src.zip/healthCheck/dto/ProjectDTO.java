package com.allianz.healthCheck.dto;

public class ProjectDTO {
	
	private Integer id;
	private String projectName;
	private String department;
	private int headCount;
	private int businessWeightage;
	private String developmentMethodlogy;
	
	private String projectDecription;
	private String serviceOwnerIT;
	private String serviceOwnerITEmail;
	private long serviceOwnerITNumber;
	
	
	private String serviceOwnerBusiness;
	private String serviceOwnerBusinessEmail;
	private long serviceOwnerBusinessNumber;
	
	
	private String serviceManager;
	private String serviceManagerEmail;
	private long serviceManagerNumber;
	
	private int activeSLA;
	private int atRiskSLA;
	private int breachedSLA;
	
	public ProjectDTO() {
		super();
	}
	
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getHeadCount() {
		return headCount;
	}
	public void setHeadCount(int headCount) {
		this.headCount = headCount;
	}
	public int getBusinessWeightage() {
		return businessWeightage;
	}
	public void setBusinessWeightage(int businessWeightage) {
		this.businessWeightage = businessWeightage;
	}
	public String getDevelopmentMethodlogy() {
		return developmentMethodlogy;
	}
	public void setDevelopmentMethodlogy(String developmentMethodlogy) {
		this.developmentMethodlogy = developmentMethodlogy;
	}
	public String getProjectDecription() {
		return projectDecription;
	}
	public void setProjectDecription(String projectDecription) {
		this.projectDecription = projectDecription;
	}
	public String getServiceOwnerIT() {
		return serviceOwnerIT;
	}
	public void setServiceOwnerIT(String serviceOwnerIT) {
		this.serviceOwnerIT = serviceOwnerIT;
	}
	public String getServiceOwnerITEmail() {
		return serviceOwnerITEmail;
	}
	public void setServiceOwnerITEmail(String serviceOwnerITEmail) {
		this.serviceOwnerITEmail = serviceOwnerITEmail;
	}
	public long getServiceOwnerITNumber() {
		return serviceOwnerITNumber;
	}
	public void setServiceOwnerITNumber(long serviceOwnerITNumber) {
		this.serviceOwnerITNumber = serviceOwnerITNumber;
	}
	public String getServiceOwnerBusiness() {
		return serviceOwnerBusiness;
	}
	public void setServiceOwnerBusiness(String serviceOwnerBusiness) {
		this.serviceOwnerBusiness = serviceOwnerBusiness;
	}
	public String getServiceOwnerBusinessEmail() {
		return serviceOwnerBusinessEmail;
	}
	public void setServiceOwnerBusinessEmail(String serviceOwnerBusinessEmail) {
		this.serviceOwnerBusinessEmail = serviceOwnerBusinessEmail;
	}
	public long getServiceOwnerBusinessNumber() {
		return serviceOwnerBusinessNumber;
	}
	public void setServiceOwnerBusinessNumber(long serviceOwnerBusinessNumber) {
		this.serviceOwnerBusinessNumber = serviceOwnerBusinessNumber;
	}
	public String getServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(String serviceManager) {
		this.serviceManager = serviceManager;
	}
	public String getServiceManagerEmail() {
		return serviceManagerEmail;
	}
	public void setServiceManagerEmail(String serviceManagerEmail) {
		this.serviceManagerEmail = serviceManagerEmail;
	}
	public long getServiceManagerNumber() {
		return serviceManagerNumber;
	}
	public void setServiceManagerNumber(long serviceManagerNumber) {
		this.serviceManagerNumber = serviceManagerNumber;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getActiveSLA() {
		return activeSLA;
	}

	public void setActiveSLA(int activeSLA) {
		this.activeSLA = activeSLA;
	}

	public int getAtRiskSLA() {
		return atRiskSLA;
	}

	public void setAtRiskSLA(int atRiskSLA) {
		this.atRiskSLA = atRiskSLA;
	}

	public int getBreachedSLA() {
		return breachedSLA;
	}

	public void setBreachedSLA(int breachedSLA) {
		this.breachedSLA = breachedSLA;
	}

	

}
