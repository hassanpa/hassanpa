package com.allianz.healthCheck.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ProjectHealthSummary {
	
	private String analysisName;
	
	private String remarks;
	
	private HealthSummary healthSummary;
	
	private List<HealthSummary> detailedHealthSummary=new ArrayList<HealthSummary>();

	public ProjectHealthSummary(String analysisName,String remarks,HealthSummary healthSummary, List<HealthSummary> detailedHealthSummary) {
		super();
		this.healthSummary = healthSummary;
		this.remarks=remarks;
		this.detailedHealthSummary = detailedHealthSummary;
		this.analysisName= analysisName;
	}
	
	public ProjectHealthSummary(String analysisName,String remarks,HealthSummary healthSummary) {
		super();
		this.healthSummary = healthSummary;
		this.remarks=remarks;
		this.analysisName= analysisName;
	}
	
	public static ProjectHealthSummary create(String analysisName,String remarks,HealthSummary healthSummary) {
		return new ProjectHealthSummary(analysisName,remarks,healthSummary);
	}

	public HealthSummary getHealthSummary() {
		return healthSummary;
	}

	public void setHealthSummary(HealthSummary kpiSummary) {
		this.healthSummary = kpiSummary;
	}

	public List<HealthSummary> getDetailedHealthSummary() {
		return detailedHealthSummary;
	}

	public void setDetailedHealthSummary(List<HealthSummary> detailedHealthSummary) {
		this.detailedHealthSummary = detailedHealthSummary;
	}

	public String getAnalysisName() {
		return analysisName;
	}

	public void setAnalysisName(String analysisName) {
		this.analysisName = analysisName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	public static BigDecimal sumOfHealthScore(List<ProjectHealthSummary> healthSummaries) {
		BigDecimal totalScore = BigDecimal.valueOf(0);
		for (ProjectHealthSummary summary : healthSummaries) {
			totalScore = totalScore.add(summary.getHealthSummary().getScore());
		}
		return totalScore;
	}

	@Override
	public String toString() {
		return "ProjectHealthSummary [analysisName=" + analysisName + ", remarks=" + remarks + ", healthSummary="
				+ healthSummary + ", detailedHealthSummary=" + detailedHealthSummary + "]";
	}

}
 