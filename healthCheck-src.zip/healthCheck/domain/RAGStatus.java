package com.allianz.healthCheck.domain;

public enum RAGStatus {
	GREEN,AMBER,RED;
	

}
