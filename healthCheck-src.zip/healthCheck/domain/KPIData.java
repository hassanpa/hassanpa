package com.allianz.healthCheck.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class KPIData {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	private int value;
	private String comments;
	private Date reportingPeriod;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "kpi_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	private KPI kpi;
	
	protected KPIData() {
			
	}

	public KPIData(int value, String comments, Date reportingPeriod, KPI kpi) {
		super();
		this.value = value;
		this.comments = comments;
		this.reportingPeriod = reportingPeriod;
		this.kpi = kpi;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getReportingPeriod() {
		return reportingPeriod;
	}

	public void setReportingPeriod(Date reportingPeriod) {
		this.reportingPeriod = reportingPeriod;
	}

	public KPI getKpi() {
		return kpi;
	}

	public void setKpi(KPI kpi) {
		this.kpi = kpi;
	}

	@Override
	public String toString() {
		return "KPIData [id=" + id + ", value=" + value + ", comments=" + comments + ", reportingPeriod="
				+ reportingPeriod + ", kpi=" + kpi + "]";
	}
	
	
	
	
	
	
	
	

}
