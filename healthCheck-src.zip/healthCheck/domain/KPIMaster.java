package com.allianz.healthCheck.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class KPIMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String kpiName;
	private String kpiDescription;

	protected KPIMaster() {

	}

	public KPIMaster(String kpiName, String kpiDescription) {
		super();
		this.kpiName = kpiName;
		this.kpiDescription = kpiDescription;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getKpiName() {
		return kpiName;
	}

	public void setKpiName(String kpiName) {
		this.kpiName = kpiName;
	}

	public String getKpiDescription() {
		return kpiDescription;
	}

	public void setKpiDescription(String kpiDescription) {
		this.kpiDescription = kpiDescription;
	}

	@Override
	public String toString() {
		return "KPIMaster [kpiName=" + kpiName + ", kpiDescription=" + kpiDescription + "]";
	}

}
