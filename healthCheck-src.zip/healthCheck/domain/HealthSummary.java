package com.allianz.healthCheck.domain;

import java.math.BigDecimal;
import java.util.List;

public class HealthSummary {
	private String kpiName;
	private BigDecimal score;
	private RAGStatus ragStatus;
	private int value;
	private int businessWeightage;
	private int maxThreshold;
	private int minThreshold;
	
	
	
	
	private KPI kpi;
	private KPIData kpiData;
	
	public HealthSummary() {
		
	}
	
	private HealthSummary(String kpiName,BigDecimal score,RAGStatus riskLevel,int value,int businessWeightage,int maxThreshold,int minThreshold) {
		this.kpiName=kpiName;
		this.score=score;
		this.ragStatus=riskLevel;
		this.businessWeightage=businessWeightage;
		this.value=value;
		this.maxThreshold=maxThreshold;
		this.minThreshold=minThreshold;
		
	}
	
	public HealthSummary(String kpiName,BigDecimal score,RAGStatus riskLevel,int value,int businessWeightage,int maxThreshold,int minThreshold,KPI kpi,KPIData kpiData) {
		this.kpiName=kpiName;
		this.score=score;
		this.ragStatus=riskLevel;
		this.businessWeightage=businessWeightage;
		this.value=value;
		this.maxThreshold=maxThreshold;
		this.minThreshold=minThreshold;
		this.kpi=kpi;
		this.kpiData=kpiData;
		
	}

	public static HealthSummary create (String name,BigDecimal score,RAGStatus riskLevel,int value,int businessWeightage,int maxThreshold,int minThreshold) {
		HealthSummary healthSummary=new HealthSummary(name,score,riskLevel,value,businessWeightage,maxThreshold,minThreshold);
		return healthSummary;
	}
	public BigDecimal getScore() {
		return score;
	}

	public void setScore(BigDecimal score) {
		this.score = score;
	}

	public RAGStatus getRAGStatus() {
		return ragStatus;
	}

	public void setRAGStatus(RAGStatus ragStatus) {
		this.ragStatus = ragStatus;
	}

	public int getBusinessWeightage() {
		return businessWeightage;
	}

	public void setBusinessWeightage(int businessWeightage) {
		this.businessWeightage = businessWeightage;
	}

	public String getKpiName() {
		return kpiName;
	}

	public void setKpiName(String kpiName) {
		this.kpiName = kpiName;
	}

	public KPI getKpi() {
		return kpi;
	}

	public void setKpi(KPI kpi) {
		this.kpi = kpi;
	}

	public KPIData getKpiData() {
		return kpiData;
	}

	public void setKpiData(KPIData kpiData) {
		this.kpiData = kpiData;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getMaxThreshold() {
		return maxThreshold;
	}

	public void setMaxThreshold(int maxThreshold) {
		this.maxThreshold = maxThreshold;
	}

	public int getMinThreshold() {
		return minThreshold;
	}

	public void setMinThreshold(int minThreshold) {
		this.minThreshold = minThreshold;
	}
	
	
	public static BigDecimal sumOfHealthScore(List<HealthSummary> healthSummaries) {
		BigDecimal totalScore = BigDecimal.valueOf(0);
		for (HealthSummary summary : healthSummaries) {
			totalScore = totalScore.add(summary.getScore());
		}
		return totalScore;
	}

	@Override
	public String toString() {
		return "HealthSummary [kpiName=" + kpiName + ", score=" + score + "/"+businessWeightage+", ragStatus=" + ragStatus + ", value=" + value
				+ ", businessWeightage=" + businessWeightage + ", maxThreshold=" + maxThreshold + ", minThreshold="
				+ minThreshold + "]";
	}

	
	
}
