package com.allianz.healthCheck.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;

@Entity
public class Organization {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private String organization;

	private String organizationDescription;

	private String country;

	public Organization(String organization, String organizationDescription, String country) {
		super();
		this.organization = organization;
		this.organizationDescription = organizationDescription;
		this.country = country;
	}

	public Organization() {
	}

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getOrganizationDescription() {
		return organizationDescription;
	}

	public void setOrganizationDescription(String organizationDescription) {
		this.organizationDescription = organizationDescription;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Organization [id=" + id + ", organization=" + organization + ", organizationDescription="
				+ organizationDescription + ", country=" + country + "]";
	}

}
