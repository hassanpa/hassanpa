package com.allianz.healthCheck.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class ServiceOffering {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private String serviceName;
	
	private String serviceDecription;
	
	private int businessWeightage;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "operatingEntity_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	private OperatingEntity operatingEntity;
	
	public ServiceOffering() {
	}
	
	public ServiceOffering(String serviceName, String serviceDecription,int businessWeightage, OperatingEntity operatingEntity ) {
		super();
		this.serviceName = serviceName;
		this.serviceDecription = serviceDecription;
		this.operatingEntity=operatingEntity;
		this.businessWeightage=businessWeightage;
	}


	public int getBusinessWeightage() {
		return businessWeightage;
	}

	public void setBusinessWeightage(int businessWeightage) {
		this.businessWeightage = businessWeightage;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceDecription() {
		return serviceDecription;
	}

	public void setServiceDecription(String serviceDecription) {
		this.serviceDecription = serviceDecription;
	}

	public OperatingEntity getOperatingEntity() {
		return operatingEntity;
	}

	public void setOperatingEntity(OperatingEntity operatingEntity) {
		this.operatingEntity = operatingEntity;
	}

	public Integer getId() {
		return id;
	}
}
