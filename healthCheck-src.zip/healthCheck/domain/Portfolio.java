package com.allianz.healthCheck.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Portfolio {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private String portfolioName;

	private String portfolioDecription;

	private String solution;

	private String portfolioModel;

	private int businessWeightage;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "serviceOffering_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	private ServiceOffering serviceOffering;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getPortfolioDecription() {
		return portfolioDecription;
	}

	public void setPortfolioDecription(String portfolioDecription) {
		this.portfolioDecription = portfolioDecription;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public String getPortfolioModel() {
		return portfolioModel;
	}

	public void setPortfolioModel(String portfolioModel) {
		this.portfolioModel = portfolioModel;
	}

	public int getBusinessWeightage() {
		return businessWeightage;
	}

	public void setBusinessWeightage(int businessWeightage) {
		this.businessWeightage = businessWeightage;
	}

	public ServiceOffering getServiceOffering() {
		return serviceOffering;
	}

	public void setServiceOffering(ServiceOffering serviceOffering) {
		this.serviceOffering = serviceOffering;
	}
	
	protected Portfolio() {
		
	}

	public Portfolio(String portfolioName, String portfolioDecription, String solution, String portfolioModel,
			int businessWeightage, ServiceOffering serviceOffering) {
		super();
		this.portfolioName = portfolioName;
		this.portfolioDecription = portfolioDecription;
		this.solution = solution;
		this.portfolioModel = portfolioModel;
		this.businessWeightage = businessWeightage;
		this.serviceOffering = serviceOffering;
	}
	

}
