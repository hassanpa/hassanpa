package com.allianz.healthCheck.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class KPI {
	

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "kpimaster_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	private KPIMaster kpiMaster;
	
	
	private int thresholdMax;
	private int thresholdMin;
	private int businessWeightage;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "project_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Project project;

	

	protected KPI() {
		
	}

	public KPI(KPIMaster kpiMaster, int thresholdMax, int thresholdMin, int businessWeightage,
			Project project) {
		super();
		this.thresholdMax = thresholdMax;
		this.thresholdMin = thresholdMin;
		this.businessWeightage=businessWeightage;
		this.project = project;
		this.kpiMaster=kpiMaster;
	}
	
	public int getBusinessWeightage() {
		return businessWeightage;
	}

	public void setBusinessWeightage(int businessWeightage) {
		this.businessWeightage = businessWeightage;
	}

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}

	public int getThresholdMax() {
		return thresholdMax;
	}



	public void setThresholdMax(int thresholdMax) {
		this.thresholdMax = thresholdMax;
	}



	public int getThresholdMin() {
		return thresholdMin;
	}



	public void setThresholdMin(int thresholdMin) {
		this.thresholdMin = thresholdMin;
	}



	public Project getProject() {
		return project;
	}



	public void setProject(Project project) {
		this.project = project;
	}

	public KPIMaster getKpiMaster() {
		return kpiMaster;
	}

	public void setKpiMaster(KPIMaster kpiMaster) {
		this.kpiMaster = kpiMaster;
	}

	@Override
	public String toString() {
		return "KPI [kpiMaster=" + kpiMaster + ", thresholdMax=" + thresholdMax + ", thresholdMin=" + thresholdMin
				+ ", businessWeightage=" + businessWeightage + ", project=" + project + "]";
	}

	
	
	


	
}
